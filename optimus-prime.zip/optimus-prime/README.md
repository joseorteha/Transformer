# Optimus Prime Toggle with CSS Transform 👀😅 [cpc-toggles]

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/MWzwamV](https://codepen.io/jh3y/pen/MWzwamV).

